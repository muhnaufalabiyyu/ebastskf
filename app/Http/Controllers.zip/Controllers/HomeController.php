<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class HomeController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        $supplier_code = $user->supplier_id;

        $po = DB::table('purchase_order')
            ->select('no_po', 'date_po', 'no_pp', 'date_pp', 'date_eta', 'date_send', 'date_delivery_schedule', 'is_send', 'baststatus', 'supplier_code')
            ->where('supplier_code', $supplier_code)
            ->where('baststatus', 0)
            ->distinct()
            ->get();

        if (Auth::user()->acting == 1) {
            return view('home', compact('po'));
        } elseif (Auth::user()->acting == 2) {
            return redirect()->route('approval');
        }
    }

    public function createbast($pono)
    {
        $user = Auth::user();
        $supplier_code = $user->supplier_id;

        $po2 = DB::table('purchase_order')
            ->where('supplier_code', $supplier_code)
            ->where('no_po', $pono)
            ->limit(1)
            ->get();

        $pono = $po2->pluck('no_po');

        $itempo = DB::table('purchase_order')
            ->where('no_po', $pono)
            ->get();

        $supplier = DB::table('supplier')
            ->where('supplier_id', $supplier_code)
            ->get();

        $alias = json_decode($supplier->pluck('aliases'), true)[0];

        $lastbast = DB::table('bast')
            ->where('supplier_id', $supplier_code)
            ->orderBy('id_bast', 'desc')
            ->first();

        if ($lastbast) {
            $lastbastno = explode('/', $lastbast->bastno);
            $number = intval($lastbastno[0]);
            $nextnum = $number + 1;

            $nextbastnum = str_pad($nextnum, strlen($lastbastno[0]), '0', STR_PAD_LEFT) . '/' . implode('/', array_slice($lastbastno, 1));
        } else {
            $nextbastnum = '001/' . $alias . '/BAST/MTNC/' . Carbon::now()->month . '/' . Carbon::now()->year;
            // $nextbastnum = $aliases;
        }

        return view('createbast', ['bastnumber' => $nextbastnum], compact('po2', 'supplier', 'itempo'));
    }
}
