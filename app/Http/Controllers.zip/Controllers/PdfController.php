<?php

namespace App\Http\Controllers;

use Barryvdh\DomPDF\PDF;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Exception;

class PdfController extends Controller
{
    public function generatePDF($id, $supplier_id)
    {
        try {
            $user = Auth::user();
            $bast = DB::table('bast')
                ->select(
                    '*',
                    DB::raw('DATE_FORMAT(bastdt, "%d-%m-%Y") as bast_dt'),
                    DB::raw('DATE_FORMAT(workstart, "%d-%m-%Y") as work_start'),
                    DB::raw('DATE_FORMAT(workend, "%d-%m-%Y") as work_end'),
                    DB::raw('DATE_FORMAT(userappvdt, "%d-%m-%Y %H:%i:%s") as userappv_dt'),
                    DB::raw('DATE_FORMAT(ehsappvdt, "%d-%m-%Y %H:%i:%s") as ehsappv_dt'),
                    DB::raw('DATE_FORMAT(purchappvdt, "%d-%m-%Y %H:%i:%s") as purchappv_dt'),
                    DB::raw('DATE_FORMAT(rrdt, "%d-%m-%Y %H:%i:%s") as rr_dt'),
                    DB::raw('DATE_FORMAT(created_at, "%d-%m-%Y %H:%i:%s") as createdat')
                )
                ->where('id_bast', $id)
                ->get();

            $pono = $bast->pluck('pono');
            $spid = $bast->pluck('supplier_id');

            $supplier = DB::table('supplier')
                ->where('supplier_id', $spid)
                ->get();

            $query = DB::table('purchase_order')
                ->where('no_po', $pono)
                ->get();

            if ($user->acting == 2) {
                $pdf = app('dompdf.wrapper')->loadView('pdfbast', compact('query', 'bast', 'supplier'));
            } elseif ($user->acting == 1) {
                if ($user->supplier_id == $supplier_id) {
                    $pdf = app('dompdf.wrapper')->loadView('pdfbast', compact('query', 'bast', 'supplier'));
                } else {
                    return redirect()->route('history');
                }
            } else {
                return redirect()->route('history');
            }
        } catch (Exception $e) {
            Session::flash('error', $e->getMessage());
        }

        return $pdf->stream('example.pdf');
    }
}
?>