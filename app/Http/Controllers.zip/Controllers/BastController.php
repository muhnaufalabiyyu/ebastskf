<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Carbon;
use Exception;
use App\BeritaAcara;

class BastController extends Controller
{
    public function store_bast(Request $request)
    {
        try {
            $copypo = $request->file('copypo');
            $offerfile = $request->file('offerfile');
            $reportfile = $request->file('reportfile');

            $copyponame = $copypo->getClientOriginalName();
            $offerfilename = $offerfile->getClientOriginalName();
            $reportfilename = $reportfile->getClientOriginalName();

            $copypopath = 'public/files/copypo/' . $copyponame;
            $offerfilepath = 'public/files/offerfile/' . $offerfilename;
            $reportfilepath = 'public/files/reportfile/' . $reportfilename;

            Storage::disk('local')->put($copypopath, file_get_contents($copypo));
            Storage::disk('local')->put($offerfilepath, file_get_contents($offerfile));
            Storage::disk('local')->put($reportfilepath, file_get_contents($reportfile));

            DB::transaction(function () use ($request, $copypopath, $offerfilepath, $reportfilepath) {
                $bast = new BeritaAcara([
                    'pono' => $request->input('ponumber'),
                    'offerno' => $request->input('offernumber'),
                    'bastno' => $request->input('bastnumber'),
                    'bastdt' => Carbon::now(),
                    'createdby' => $request->input('createdby'),
                    'workstart' => $request->input('startdate'),
                    'workend' => $request->input('enddate'),
                    'workdesc' => $request->input('jobname'),
                    'status' => '0',
                    'supplier_id' => Auth::user()->supplier_id,
                    'copypofile' => $copypopath,
                    'offerfile' => $offerfilepath,
                    'reportfile' => $reportfilepath,
                    'to_user' => $request->input('userapproval')
                ]);

                $bast->save();

                $pono = $request->input('ponumber');
                DB::table('purchase_order')
                    ->where('no_po', $pono)
                    ->update([
                        'baststatus' => '1',
                        'bastdt' => Carbon::now(),
                        'bastusr'=> Auth::user()->name,
                    ]);
            }, 5);

            Session::flash('success', 'Berita Acara anda berhasil dibuat');
            return redirect('history');
        } catch (Exception $e) {
            DB::rollBack();
            Session::flash('error', $e->getMessage());
        }
    }
}
