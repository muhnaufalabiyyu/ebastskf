<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Mail;
use App\Mail\SKFMail;
use Exception;
use Carbon\Carbon;

class ApprovalController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        $role = $user->dept;
        if ($role == 'Admin') {
            $approval = DB::table('bast')->get();
        } elseif ($role == 'EHS') {
            $approval = DB::table('bast')
                ->where('status', '2')
                ->get();
        } elseif ($role == 'Purchasing') {
            $approval = DB::table('bast')
                ->where('status', '3')
                ->get();
        } elseif ($role == 'WH') {
            $approval = DB::table('bast')
                ->where('status', '4')
                ->get();
        } else {
            $approval = DB::table('bast')
                ->where('status', '0')
                ->where('to_user', $role)
                ->orWhere('status', '1')
                ->get();
        }

        return view('approval', compact('approval'));
    }

    public function rating(Request $request, $id)
    {
        try {
            // $user = Auth::user();
            $rate = $request->input('rateid' . $id);

            DB::table('bast')
                ->where('id_bast', $id)
                ->update(['user_rate' => $rate, 'status' => 1]);

            DB::commit();
            return redirect()->route('approval');
        } catch (Exception $e) {
            DB::rollBack();
            Session::flash('error', $e->getMessage());
        }
    }

    public function approve(Request $request)
    {
        try {
            $id = request('id');
            $userappv = request('userappv');
            
            $user = Auth::user();
            if ($user->dept == 'EHS') {
                $status = 3;
                $notes = $request->input('ehsnotes');
                $usrappv = 'ehsappv';
                $field = 'ehsappvdt';
                $field2 = 'ehsnotes';
            } elseif ($user->dept == 'Purchasing') {
                $status = 4;
                $usrappv = 'purchappv';
                $field = 'purchappvdt';
            } elseif ($user->dept == 'WH') {
                $status = 5;
                $usrappv = 'rrusr';
            } else {
                // User except 3 above
                $status = 2;
                $usrappv = 'userappv';
                $field = 'userappvdt';
            }

            $pono = request('pono');

            if ($user->dept == 'WH') {
                DB::transaction(function () use ($id, $user, $pono, $status, $userappv, $usrappv) {
                    DB::table('bast')
                        ->where('id_bast', $id)
                        ->update(['status' => $status, $usrappv => $userappv, 'rrdt' => Carbon::now(), 'updated_at' => Carbon::now()]);

                    DB::table('purchase_order')
                        ->where('no_po', $pono)
                        ->update(['rrstatus' => 2, 'rrdt' => Carbon::now(), 'rrusr' => $user->name]);
                    // Mail::to('muhnaufalabiyyu@gmail.com')->send(new SKFMail());
                });
            } elseif ($user->dept == 'EHS') {
                DB::transaction(function () use ($id, $field, $field2, $status, $notes, $userappv, $usrappv) {
                    DB::table('bast')
                        ->where('id_bast', $id)
                        ->update(['status' => $status, $usrappv => $userappv, $field => Carbon::now(), $field2 => $notes, 'updated_at' => Carbon::now()]);
                });
            } else {
                DB::transaction(function () use ($id, $field, $status, $userappv, $usrappv) {
                    DB::table('bast')
                        ->where('id_bast', $id)
                        ->update(['status' => $status, $usrappv => $userappv, $field => Carbon::now(), 'updated_at' => Carbon::now()]);
                });
            }

            return redirect()->route('approval');
        } catch (Exception $e) {
            DB::rollback();
            Session::flash('error', $e->getMessage());
        }
    }

    public function deny(Request $request, $id)
    {
        try {
            DB::beginTransaction();

            DB::table('bast')
                ->where('id', $id)
                ->update(['status' => 3, 'denyact' => $request->input('denyact')]);

            DB::commit();
            return view('approval');
        } catch (Exception $e) {
            DB::rollback();
            Session::flash('error', $e->getMessage());
        }
    }
}
