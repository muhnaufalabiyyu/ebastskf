$(document).ready(function () {
    // Show / hide modal
    $('#btnhistory').click(function() {
        $('#modalHistory').modal('show');
    });

    $('.closeHistory').click(function() {
        $('#modalHistory').modal('hide');
    });

    $('#btnRateModal').click(function() {
        $('#modalRate').modal('show');
    });

    $('.closeModalRate').click(function() {
        $('#modalRate').modal('hide');
    });

    $('#btnEHSModal').click(function() {
        $('#modalEHSNotes').modal('show');
    });

    $('.closeModalEHS').click(function() {
        $('#modalEHSNotes').modal('hide');
    });
    // End of show / hide modal

    // Datatable Format
    $(".tbHistory").DataTable({
        dom: "Bfrtip",
        columnDefs: [{ className: "dt-center", targets: "_all" }],
        "language": {
            "emptyTable": "Tidak ada BAST yang dibuat oleh Supplier."
        },
        pageLength: 10
    });
    
    $(".tbPOReady").DataTable({
        dom: "Bfrtip",
        columnDefs: [{ className: "dt-center", targets: "_all" }],
        "language": {
            "emptyTable": "Tidak ada Purchase Order yang harus di BAST."
        },
        pageLength: 10
    });

    $(".tbApproval").DataTable({
        dom: "Bfrtip",
        columnDefs: [{ className: "dt-center", targets: "_all" }],
        "language": {
            "emptyTable": "Tidak ada BAST yang harus di approve."
        },
        pageLength: 10
    });

    $(".tbItemPO").DataTable({
        // searching: "false",
        dom: "rtip",
        columnDefs: [{ className: "dt-center", targets: "_all" }],
        pageLength: 10
    });

    // End of Datatable Format
    
    $('.deny-button').click(function(e) {
        e.preventDefault();
        var route = $(this).data('route');
        $.post(route, function(data) {
            // Handle the response or perform any desired actions for deny
        });
    });
});
